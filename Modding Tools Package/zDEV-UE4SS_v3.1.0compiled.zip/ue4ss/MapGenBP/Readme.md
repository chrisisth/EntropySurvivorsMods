## UE4SS Map Dumper - Map Gen Editor BP

Extract to your project's content folder (Content/MapGen/)

Import the dumped .csv file as a datatable based on "MapSpawnStruct".

Drag the BP onto an empty map.

Select the Actor within the map, and set the relevant datatable.

Press "Create Map" under default in the details tab.