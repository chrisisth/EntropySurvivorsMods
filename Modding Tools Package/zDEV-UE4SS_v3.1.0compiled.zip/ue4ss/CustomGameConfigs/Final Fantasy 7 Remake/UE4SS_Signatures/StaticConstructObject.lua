function Register()
    return "4 8/8 9/5 C/2 4/1 8/5 5/5 6/5 7/4 1/5 4/4 1/5 5/4 1/5 6/4 1/5 7/4 8/8 1/E C/A 0/0 1/0 0/0 0/4 8/8 B"
end

function OnMatchFound(MatchAddress)
    return MatchAddress
end