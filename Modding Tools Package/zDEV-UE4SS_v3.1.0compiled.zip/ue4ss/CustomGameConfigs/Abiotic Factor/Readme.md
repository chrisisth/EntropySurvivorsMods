Abiotic Factor is game made completely with Blueprints and is currently in Early Access.
Right now it uses UE 5.4.4.
UE4SS works, but is unstable. It often crashes when leaving the game to main menu or sometimes after loading into a game.
But works during a play session most of the time, with rare crashes.
  