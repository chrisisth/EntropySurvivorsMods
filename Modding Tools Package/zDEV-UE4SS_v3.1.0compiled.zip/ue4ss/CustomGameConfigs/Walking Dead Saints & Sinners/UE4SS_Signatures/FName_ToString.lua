function Register()
    return "48 89 5C 24 08 48 89 6C 24 10 48 89 74 24 18 57 48 83 EC 20 48 8B DA 48 8B F1 E8 ?? ?? ?? ?? 44 8B 46 04"
end

function OnMatchFound(MatchAddress)
    return MatchAddress
end