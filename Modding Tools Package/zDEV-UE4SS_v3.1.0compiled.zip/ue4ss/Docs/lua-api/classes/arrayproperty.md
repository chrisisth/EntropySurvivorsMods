# ArrayProperty

## Inheritance
[Property](./property.md)

## Methods

### GetInner()

- **Return type:** `Property`
- **Returns:** the inner property of the array.