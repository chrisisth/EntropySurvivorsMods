# UObjectReflection

## Inheritance
None

## Methods

### GetProperty(string PropertyName)

- **Return type:** `Property`
- **Returns:** a property meta-data object.