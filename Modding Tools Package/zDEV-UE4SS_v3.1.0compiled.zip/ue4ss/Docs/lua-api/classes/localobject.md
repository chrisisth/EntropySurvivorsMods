# LocalObject

The `LocalObject` class is the second of two base objects that all other objects inherits from, the other one being [RemoteObject](./remoteobject.md).

It contains an inlined C++ object that is owned by Lua.

## Inheritance
None

## Methods
None