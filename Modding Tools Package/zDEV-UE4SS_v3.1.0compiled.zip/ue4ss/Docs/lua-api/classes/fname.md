# FName

## Inheritance
[LocalObject](./localobject.md)

## Methods

### ToString()

- **Return type:** `string`
- **Returns:** the string for this `FName`.

### GetComparisonIndex()

- **Return type:** `integer`
- **Returns:** the `ComparisonIndex` for this `FName` (index into global names array).