# ObjectProperty

## Inheritance
[Property](./property.md)

## Methods

### GetPropertyClass()

- **Return type:** `UClass`
- **Returns:** the class that this property holds.