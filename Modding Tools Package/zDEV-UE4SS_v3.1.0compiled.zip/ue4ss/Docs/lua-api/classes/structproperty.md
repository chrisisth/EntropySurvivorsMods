# StructProperty

## Inheritance
[Property](./property.md)

## Methods

### GetStruct()

- **Return type:** `UScriptStruct`
- **Returns:** the `UScriptStruct` that's mapped to this property.