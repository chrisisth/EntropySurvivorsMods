# BoolProperty

## Inheritance
[Property](./property.md)

## Methods

### GetByteMask()

- **Return type:** `integer`

### GetByteOffset()

- **Return type:** `integer`

### GetFieldMask()

- **Return type:** `integer`

### GetFieldSize()

- **Return type:** `integer`