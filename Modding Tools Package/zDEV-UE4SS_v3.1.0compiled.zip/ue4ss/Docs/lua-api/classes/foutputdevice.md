# FOutputDevice

## Inheritance
[RemoteObject](./remoteobject.md)

## Methods

### Log(string Message)

- Logs a message to the output device (i.e: the in-game console).