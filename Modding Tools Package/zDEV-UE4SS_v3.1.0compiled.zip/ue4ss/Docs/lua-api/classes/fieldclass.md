# FieldClass

## Inheritance
[LocalObject](./localobject.md)

## Methods

### GetFName()

- **Return type:** `FName`
- **Returns:** the FName of this class by copy.