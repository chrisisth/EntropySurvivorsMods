# FText

## Inheritance
[LocalObject](./localobject.md)

## Methods

### ToString()

- **Return type:** `string`
- **Returns:** the string representation of this `FText`.
