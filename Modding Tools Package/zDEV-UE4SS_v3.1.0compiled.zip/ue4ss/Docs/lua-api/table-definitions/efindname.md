# EFindName

Field Name | Field Value Type
--------- | --------------
FNAME_Find               | 0
FNAME_Add                | 1
