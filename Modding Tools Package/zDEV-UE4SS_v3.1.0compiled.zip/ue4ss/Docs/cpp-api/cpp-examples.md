# C++ Examples

Template repository for making UE4SS C++ mods: [UE4SSCPPTemplate](https://github.com/UE4SS-RE/UE4SSCPPTemplate) - note that if you are developing on latest main branch, you should use the `dev` branch of this template repo if there are any changes to the template that are not yet merged into `main`.

Search GitHub for any Lua code calling reasonably uniquely-named UE4SS API functions, excluding the actual UE4SS repository from the search:

https://github.com/search?q=language%3Acpp++%22+%3A+public+CppUserModBase%22+NOT+repo%3AUE4SS-RE%2FRE-UE4SS+NOT+repo%3AEpicGames%2FUnrealEngine&type=code