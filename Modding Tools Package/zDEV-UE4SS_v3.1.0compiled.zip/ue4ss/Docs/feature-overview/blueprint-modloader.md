# Blueprint Modloader

As our BP system is based on RussellJ's, this tutorial video is applicable for creating a blueprint mod for UE4SS:

<iframe width="560" height="315" src="https://www.youtube.com/embed/fB3yT85XhVA?si=Hvu0wHmcFxFT2MA_" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>